import pygame
from random import *
import sys
from pygame.locals import *

#2-Initialization
pygame.init()

def selectObs(num):
    if num == 0:
        return frelon
    else:
        return tracteur

def init(width, height):

    Bee = [bee,100,200]
    screen = pygame.display.set_mode((width, height))
    return screen, Bee

def keydetection():
    #update events
    for event in pygame.event.get():
        #detect mouse click to close the window
        if event.type==pygame.QUIT:
            pygame.quit()
            sys.exit(0)
        
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_DOWN:
                return 30
            elif event.key == pygame.K_UP:
                return -30
            elif event.key == pygame.K_ESCAPE:
                pygame.quit()
                sys.exit(0)
            elif event.key == pygame.K_SPACE:
                return 1
     
    return 0

def obstacle_generator(lst_obstacles, Bee):
    for _ in range(randint(1,3)):
        not_created=True
        
        while not_created:
            x= Bee[1] + randint(height,height+200)
            y=randint(0,width-50)

            if checker_position(lst_obstacles,x,y) and checker_position(lst_flowers,x,y):
                lst_obstacles.append([selectObs(randint(0,2)),x,y])
                not_created=False

def flower_generator(lst_flowers,Bee, lst_obstacles):

    for _ in range(randint(1,2)):
        not_created=True
        
        while not_created:
            x= Bee[1] + randint(height,height+200)
            y= randint(0,width-50)

            if checker_position(lst_obstacles,x,y) and checker_position(lst_flowers,x,y) :
                lst_flowers.append([fleur,x,y])
                not_created=False

def checker_position(lst,x,y):
    if y-50 < 0 or y+50 > height:
        return False
    for i in lst:
        if (i[1] in range(x-100,x+100)) and (i[2] in range(y-100,y+100)):
            return False
    return True

#Main

width = 800
height = 600

bee = pygame.image.load("resources/image/bee.png")
frelon = pygame.image.load("resources/image/bourdon.png")
fleur = pygame.image.load("resources/image/fleur.png")
tracteur = pygame.image.load("resources/image/tracteur.png")

running = 1
exitcode = 0

screen, Bee = init(width, height)
lst_obstacles = []
lst_flowers = []

refresh_time = True
refresh_obstacle = True

while 1:
    score = 0
    time = 0
    del lst_flowers[:]
    del lst_obstacles[:]
    while running:
        screen.fill((0,175,100))
        time += 1
        if time == 300:
            time = 0
            refresh_time = True
            refresh_obstacle = True

        Bee[2] += keydetection()
        screen.blit(Bee[0],(Bee[1],Bee[2]))

        if Bee[2] < 0:
            Bee[2] = 0
        elif Bee[2] > height-50:
            Bee[2] = height-50

        # HitBox de Bee
        birdrect = pygame.Rect(Bee[0].get_rect())
        birdrect.left = Bee[1]
        birdrect.top = Bee[2]

        #Collision avec Obstacle
        for obs in lst_obstacles:
            prect= pygame.Rect(obs[0].get_rect())
            prect.left = obs[1]
            prect.top = obs[2]
            if prect.colliderect(birdrect):
                running = 0
                exitcode = 1

        #Collision avec Fleur
        for flo in lst_flowers:
            prect= pygame.Rect(flo[0].get_rect())
            prect.left = flo[1]
            prect.top = flo[2]
            if prect.colliderect(birdrect):
                score += 1
                lst_flowers.remove(flo)


        for oneobstacle in lst_obstacles:
            screen.blit(oneobstacle[0],(oneobstacle[1],oneobstacle[2]))
            oneobstacle[1]-=0.5
            if oneobstacle[1] == -50:
                lst_obstacles.remove(oneobstacle)

        #Refresh les obstacles
        if refresh_obstacle:
           obstacle_generator(lst_obstacles, Bee)
           refresh_obstacle = False

        for oneflower in lst_flowers:
            screen.blit(oneflower[0],(oneflower[1],oneflower[2]))
            oneflower[1]-=0.5
            if oneflower[1] == -50:
                lst_flowers.remove(oneflower)

        #Refresh les fleurs
        if refresh_time:
           flower_generator(lst_flowers,Bee, lst_obstacles)
           refresh_time = False

        pygame.display.flip()


    if exitcode:
        exitfont = pygame.font.SysFont("Arial", 50)
        restartfont = pygame.font.SysFont("Arial", 30)
        exitText = exitfont.render(str(score), True, (255,0,0))
        restartText = restartfont.render("Press SPACE to restart", True, (0,0,0))
        exitTextRect = exitText.get_rect()
        restartTextRect = restartText.get_rect()
        exitTextRect.centerx = screen.get_rect().centerx
        exitTextRect.centery = screen.get_rect().centery
        restartTextRect.centerx = exitTextRect.centerx
        restartTextRect.centery = exitTextRect.centery+100
        screen.blit(exitText, exitTextRect)
        screen.blit(restartText,restartTextRect)

    #looping exit strategy
    while exitcode:    
        pygame.display.flip()
        key = keydetection()
        if key == 1:
            running = 1
            exitcode = 0
            obstacle_generator(lst_obstacles, Bee)
            flower_generator(lst_flowers,Bee,lst_obstacles)
