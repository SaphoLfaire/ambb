Bee Flapy

Evitez les obstacles et collecter le maximum de fleurs pour cumuler les points !

Mouvements :
Fleche haut -> Aller au Nord
Fleche bas -> Aller au Sud

